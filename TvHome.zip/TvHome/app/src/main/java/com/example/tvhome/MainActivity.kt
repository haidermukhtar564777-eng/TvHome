package com.example.tvhome

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// Several package names per app, because Fire TV and Android TV builds differ.
// Check yours with: adb shell pm list packages | grep -i hotstar
data class AppTile(val name: String, val packages: List<String>, val tint: Color)

val appTiles = listOf(
    AppTile("Netflix", listOf("com.netflix.ninja", "com.netflix.mediaclient"), Color(0xFFE50914)),
    AppTile("YouTube", listOf("com.amazon.firetv.youtube", "com.google.android.youtube.tv"), Color(0xFFFF2D3F)),
    AppTile("Spotify", listOf("com.spotify.tv.android", "com.spotify.music"), Color(0xFF1ED760)),
    AppTile("Hotstar", listOf("in.startv.hotstar.dplus", "in.startv.hotstar"), Color(0xFF3B8BFF)),
)

fun Context.launchIntent(pkgs: List<String>): Intent? {
    for (p in pkgs) {
        val i = packageManager.getLeanbackLaunchIntentForPackage(p)
            ?: packageManager.getLaunchIntentForPackage(p)
        if (i != null) return i
    }
    return null
}

fun Context.iconFor(pkgs: List<String>): Drawable? =
    pkgs.firstNotNullOfOrNull { p -> try { packageManager.getApplicationIcon(p) } catch (e: Exception) { null } }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var screen by remember { mutableStateOf("home") }
                Box(Modifier.fillMaxSize().background(Color(0xFF070816))) {
                    Glow()
                    if (screen == "home") {
                        BackHandler(enabled = true) { }
                        Home { screen = "assistant" }
                    } else {
                        Assistant { screen = "home" }
                    }
                }
            }
        }
    }
}

@Composable
fun Glow() {
    Box(Modifier.fillMaxSize().background(
        Brush.radialGradient(listOf(Color(0xFF3A3FA8).copy(alpha = 0.55f), Color.Transparent),
            center = Offset(300f, 150f), radius = 1100f)))
    Box(Modifier.fillMaxSize().background(
        Brush.radialGradient(listOf(Color(0xFF9B3FD0).copy(alpha = 0.35f), Color.Transparent),
            center = Offset(1750f, 950f), radius = 1000f)))
}

@Composable
fun Tile(label: String, modifier: Modifier = Modifier, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (focused) 1.14f else 1f, label = "focusScale")
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.scale(s)) {
        Box(
            modifier
                .size(160.dp)
                .clip(RoundedCornerShape(38.dp))
                .background(Color.White.copy(alpha = if (focused) 0.24f else 0.10f))
                .border(3.dp, if (focused) Color.White.copy(alpha = 0.9f) else Color.Transparent, RoundedCornerShape(38.dp))
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
            content = content
        )
        Spacer(Modifier.height(14.dp))
        Text(label, color = Color.White.copy(alpha = if (focused) 1f else 0.7f), fontSize = 20.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Home(openAssistant: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(15_000) } }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { first.requestFocus() }

    Column(Modifier.fillMaxSize().padding(horizontal = 72.dp, vertical = 56.dp)) {
        Text(now.format(DateTimeFormatter.ofPattern("h:mm")), color = Color.White, fontSize = 88.sp, fontWeight = FontWeight.Light)
        Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), color = Color.White.copy(alpha = 0.65f), fontSize = 24.sp)
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(44.dp, Alignment.CenterHorizontally)) {
            appTiles.forEachIndexed { idx, t ->
                val icon: ImageBitmap? = remember(t) { ctx.iconFor(t.packages)?.toBitmap(256, 256)?.asImageBitmap() }
                Tile(t.name, modifier = if (idx == 0) Modifier.focusRequester(first) else Modifier, onClick = {
                    val intent = ctx.launchIntent(t.packages)
                    if (intent != null) ctx.startActivity(intent)
                    else Toast.makeText(ctx, "${t.name} isn't installed", Toast.LENGTH_SHORT).show()
                }) {
                    if (icon != null) Image(icon, t.name, Modifier.size(112.dp).clip(RoundedCornerShape(26.dp)))
                    else Text(t.name.take(1), color = t.tint, fontSize = 64.sp, fontWeight = FontWeight.Bold)
                }
            }
            Tile("Assistant", onClick = openAssistant) {
                Box(Modifier.size(96.dp).clip(CircleShape).background(
                    Brush.linearGradient(listOf(Color(0xFF5AC8FA), Color(0xFFAF52DE), Color(0xFFFF2D92)))))
            }
        }
        Spacer(Modifier.weight(1.3f))
    }
}

@Composable
fun Assistant(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("tvhome", Context.MODE_PRIVATE) }
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var input by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("Type a question and press Enter.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val tts = remember { TextToSpeech(ctx, null) }
    DisposableEffect(Unit) { onDispose { tts.shutdown() } }
    BackHandler(onBack = onBack)

    fun ask() {
        if (key.isBlank()) { reply = "Paste your API key in the box below first."; return }
        if (input.isBlank()) return
        busy = true
        val q = input
        scope.launch {
            reply = try { withContext(Dispatchers.IO) { callClaude(key, q) } }
            catch (e: Exception) { "That didn't work: ${e.message}" }
            busy = false
            tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "reply")
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 120.dp, vertical = 64.dp), verticalArrangement = Arrangement.spacedBy(24.dp)) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(
            Brush.linearGradient(listOf(Color(0xFF5AC8FA), Color(0xFFAF52DE), Color(0xFFFF2D92)))))
        Text(if (busy) "Thinking…" else reply, color = Color.White, fontSize = 30.sp, lineHeight = 40.sp,
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()))
        OutlinedTextField(
            value = input, onValueChange = { input = it }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), label = { Text("Ask anything") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { ask() })
        )
        OutlinedTextField(
            value = key, onValueChange = { key = it; prefs.edit().putString("key", it).apply() },
            singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text("Anthropic API key") },
            visualTransformation = PasswordVisualTransformation()
        )
    }
}

fun callClaude(key: String, question: String): String {
    val body = JSONObject()
        .put("model", "claude-haiku-5-5")
        .put("max_tokens", 400)
        .put("system", "You are a friendly voice assistant on a TV. Answer in one to three short spoken sentences. No markdown.")
        .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", question)))
    val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
    c.requestMethod = "POST"
    c.setRequestProperty("x-api-key", key)
    c.setRequestProperty("anthropic-version", "2023-06-01")
    c.setRequestProperty("content-type", "application/json")
    c.doOutput = true
    c.outputStream.use { it.write(body.toString().toByteArray()) }
    val ok = c.responseCode in 200..299
    val text = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
    if (!ok) return "The API returned error ${c.responseCode}. Check your key."
    return JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text")
}
